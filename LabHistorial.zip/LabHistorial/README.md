# LabHistorial – Navegación con listas "Atrás / Adelante / Pendientes"

Este proyecto es una simulación sencilla de cómo funciona el historial de un navegador.  
Fue desarrollado en **C# (.NET 9.0)** usando **Visual Studio Code**.

## Objetivo
Practicar el uso de estructuras de datos (Stack y Queue en C#) aplicadas a un caso real:  
- Guardar las páginas visitadas para poder ir hacia atrás.  
- Poder volver a páginas que quedaron guardadas al retroceder.  
- Manejar páginas pendientes en espera de ser visitadas.  

## ¿Qué hace?
- **Atrás:** Guarda la página actual en una lista para regresar luego.  
- **Adelante:** Permite volver a páginas vistas después de dar “atrás”.  
- **Pendientes:** Mantiene las páginas que aún no se han visitado.  

## Cómo correrlo
1. Abre la terminal en la carpeta del proyecto.  
2. Ejecuta el siguiente comando:

```powershell
dotnet run
