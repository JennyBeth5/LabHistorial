﻿// Laboratorio: Simulación de un Historial de Navegación (Stacks & Queues)
// Jenny Beth Concepción
// COSC 309-17

using System;
using System.Collections.Generic;

namespace LabHistorial
{
    class Program
    {
        // Lista para guardar las páginas anteriores (ir hacia atrás)
        static Stack<string> atras = new Stack<string>();
        // Lista para guardar las páginas que puedo volver a ver (ir hacia adelante)
        static Stack<string> adelante = new Stack<string>();
        // Lista de páginas que todavía no he visitado (pendientes)
        static Queue<string> porVisitar = new Queue<string>();

        // Página actual
        static string actual = "home";

        static void Main(string[] args)
        {
            Console.WriteLine("=== Historial de Navegación (Stack & Queue) ===");
            Semilla(); // Cargar algunas páginas por default en pendientes

            int opcion;
            do
            {
                Console.WriteLine($"\nPágina actual: {actual}");
                Console.WriteLine("1) Visitar proxima pendiente");
                Console.WriteLine("2) Ir Atrás");
                Console.WriteLine("3) Ir Adelante");
                Console.WriteLine("4) Agregar página a pendientes");
                Console.WriteLine("5) Mostrar estado");
                Console.WriteLine("6) Salir");
                Console.Write("Opción: ");

                if (!int.TryParse(Console.ReadLine(), out opcion))
                    opcion = 0;

                switch (opcion)
                {
                    case 1:
                        VisitarSiguiente();
                        break;
                    case 2:
                        IrAtras();
                        break;
                    case 3:
                        IrAdelante();
                        break;
                    case 4:
                        AgregarACola();
                        break;
                    case 5:
                        MostrarEstado();
                        break;
                    case 6:
                        Console.WriteLine("Saliendo…");
                        break;
                    default:
                        Console.WriteLine("Opción inválida.");
                        break;
                }

            } while (opcion != 6);
        }

        // Páginas iniciales que se ponen en la lista de pendientes
        static void Semilla()
        {
            porVisitar.Enqueue("noticias");
            porVisitar.Enqueue("correo");
            porVisitar.Enqueue("universidad");
        }

        // Cambiar a la próxima página en pendientes
        static void VisitarSiguiente()
        {
            if (porVisitar.Count == 0)
            {
                Console.WriteLine("No hay páginas en espera.");
                return;
            }

            atras.Push(actual);           // push a "Atrás" para poder regresar
            actual = porVisitar.Dequeue(); // dequeue desde "Por visitar"
            adelante.Clear();             // navegar rompe la rama "Adelante"
        }

        // Simula botón “Atrás”
        static void IrAtras()
        {
            if (atras.Count == 0)
            {
                Console.WriteLine("No hay más atrás.");
                return;
            }

            adelante.Push(actual); // lo actual se guarda en "Adelante"
            actual = atras.Pop();  // pop desde "Atrás"
        }

        // Simula botón “Adelante”
        static void IrAdelante()
        {
            if (adelante.Count == 0)
            {
                Console.WriteLine("No hay más adelante.");
                return;
            }

            atras.Push(actual);   // lo actual se guarda para volver si hace falta
            actual = adelante.Pop();
        }

        // Agrega una nueva página a la lista de pendientes
        static void AgregarACola()
        {
            Console.Write("URL/nombre de la página: ");
            var p = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(p))
            {
                porVisitar.Enqueue(p.Trim());
                Console.WriteLine("Agregada a pendientes.");
            }
        }

        // Mostrar como estan las lista ahora
        static void MostrarEstado()
        {
            Console.WriteLine($"Actual: {actual}");
            Console.WriteLine("Atrás (top→bottom): " + string.Join(", ", atras));
            Console.WriteLine("Adelante (top→bottom): " + string.Join(", ", adelante));
            Console.WriteLine("Pendientes (front→back): " + string.Join(", ", porVisitar));
        }
    }
}